/* Muhammad Rehan Tariq 
	23I-0034
	AI-A
*/
#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	double total=1,lastTerm=0,i=1,thresholdValue=.000001;
	// lastTermvariable to find the term
	long count=1;
	while(true)
	{	
		i=i+2;
		lastTerm=(1/i);
		if(lastTerm<thresholdValue)
		{
		    break;
		}
		if(count%2==0)
		{
			total=total+lastTerm;
		}
		else
		{
			total=total-lastTerm;
		}
		count++;
	}
	total*=4;
	cout<<"The approximation of pie is equal to: "<<setprecision(16)<<total;
}
