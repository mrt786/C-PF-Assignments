/* Muhamm ad Rehan Tariq 
	23I-0034
	AI-A
*/
#include<iostream>
#include<cstdlib>
#include<ctime>
using namespace std;
int main()
{
	int num;
	while(true)
	{
		cout<<"Enter an even number greater than or equal to 8: ";
		cin>>num;
		if(num%2!=0)
		{
			cout<<"Enter even number"<<endl;
			//continue;
		}
		if(num>=8)//minimuim size can be 8
			break;
		else
		{
			cout<<"Entered number is not greater than 8 "<<endl;
			continue;
		}
	}
	int layer1[0][num][num],layer2[1][num][num],layer3[2][num][num];
	for(int i=0;i<num;i++)
	{
		for(int j=0;j<num;j++)
		{
			layer1[0][i][j]=0;//storing 0 in layer 1
			layer2[1][i][j]=1;//storing 1 in layer 2
			layer3[2][i][j]=2;//storing 2 in layer 3
		}
	}
	int size=num*num/4;
	int quad1[size],quad2[size],quad3[size],quad4[size];//each quadrent array
	int i,j,count=0,count1=0,count2=0,count3=0,count4=0;
	for(i=1;i<=num;i++)//dividing the layer1 into four quadrents storing the index in the quadrent array 
	{
		for(j=1;j<=num;j++)
		{
			if((i>=1 && i<=num/2) && (j>=1 && j<=(num/2)))
			{	
				quad2[count1]=count;
				count1++;
			}
			else if((i>=1 && i<=(num/2)) && (j>num/2 && j<=num))
			{
				quad1[count2]=count;
				count2++;
			}
			else if((i>(num/2))&& i<=num && (j>=1 && j<=(num/2)))
			{
				quad3[count3]=count;
				count3++;
			}
			else
			{
				quad4[count4]=count;
				count4++;
			}
			count++;
		}
	}
	
	int N=(num*num)/8;//calculating the random numbers in it
	int number=2*num*num;//total indexes till layer 3
	int quad1random[N],minValue=quad1[0],maxValue=quad1[size-1],randomNumber;
	char ch=false;
	srand(time(0));
	//printing the random numbers quadrent wise
	for(i=0;i<N;i++)
	{	ch=false;
		randomNumber=(rand()%(maxValue-minValue+1))+minValue;
		for(j=0;j<size;j++)
		{	ch=false;
			if(randomNumber!=quad2[j])
			{
				ch=true;
			}
			else
			{
				ch=false;
				break;
			}
		}
		if(ch==true)
		{	ch=true;
			for(j=0;j<N;j++)
			{
				if(i==j)
				{
					continue;
				}
				if(randomNumber==quad1random[j])
				{
					ch=false;
					break;
				}
			}
			if(ch==true)
			{
				quad1random[i]=randomNumber;
			}
			else
			{
				i--;
			}
		}
		else
		{
			i--;
		}
	}
	int quad2random[N];//random number in quadrent 2
	minValue=quad2[0],maxValue=quad2[size-1],randomNumber;
	ch=false;
	srand(time(0));
	for(i=0;i<N;i++)
	{	ch=false;
		randomNumber=(rand()%(maxValue-minValue+1))+minValue;
		for(j=0;j<size;j++)
		{	ch=false;
			if(randomNumber!=quad1[j])
			{
				ch=true;
			}
			else
			{
				ch=false;
				break;
			}
		}
		if(ch==true)
		{	ch=true;
			for(j=0;j<N;j++)
			{
				if(i==j)
				{
					continue;
				}
				if(randomNumber==quad2random[j])
				{
					ch=false;
					break;
				}
			}
			if(ch==true)
			{
				quad2random[i]=randomNumber;
			}
			else
			{
				i--;
			}
		}
		else
		{
			i--;
		}
	}//random number in quad 3
	int quad3random[N];
	minValue=quad3[0],maxValue=quad3[size-1],randomNumber;
	ch=false;
	srand(time(0));
	for(i=0;i<N;i++)
	{	ch=false;
		randomNumber=(rand()%(maxValue-minValue+1))+minValue;
		for(j=0;j<size;j++)
		{	ch=false;
			if(randomNumber!=quad4[j])
			{
				ch=true;
			}
			else
			{
				ch=false;
				break;
			}
		}
		if(ch==true)
		{	ch=true;
			for(j=0;j<N;j++)
			{
				if(i==j)
				{
					continue;
				}
				if(randomNumber==quad3random[j])
				{
					ch=false;
					break;
				}
			}
			if(ch==true)
			{
				quad3random[i]=randomNumber;
			}
			else
			{
				i--;
			}
		}
		else
		{
			i--;
		}
	}
	int quad4random[N];//random number in quad 4
	minValue=quad4[0],maxValue=quad4[size-1],randomNumber;
	ch=false;
	srand(time(0));
	for(i=0;i<N;i++)
	{	ch=false;
		randomNumber=(rand()%(maxValue-minValue+1))+minValue;
		for(j=0;j<size;j++)
		{	ch=false;
			if(randomNumber!=quad3[j])
			{
				ch=true;
			}
			else
			{
				ch=false;
				break;
			}
		}
		if(ch==true)
		{	ch=true;
			for(j=0;j<N;j++)
			{
				if(i==j)
				{
					continue;
				}
				if(randomNumber==quad4random[j])
				{
					ch=false;
					break;
				}
			}
			if(ch==true)
			{
				quad4random[i]=randomNumber;
			}
			else
			{
				i--;
			}
		}
		else
		{
			i--;
		}
	}
	int quad1layer3[N],quad2layer3[N],quad3layer3[N],quad4layer3[N];
	cout<<"First: ";
	for(i=0;i<N;i++)
	
	{
		quad1layer3[i]=quad1random[i]+number;
		cout<<quad1layer3[i]<<" ";
	}
	cout<<endl;
	cout<<"Second: ";
	for(i=0;i<N;i++)
	{
		quad2layer3[i]=quad2random[i]+number;
		cout<<quad2layer3[i]<<" ";
	}
	cout<<endl;
	cout<<"third: ";
	for(i=0;i<N;i++)
	{
		quad3layer3[i]=quad3random[i]+number;
		cout<<quad3layer3[i]<<" ";
	}
	cout<<endl;
	cout<<"Fourth: ";
	for(i=0;i<N;i++)
	{
		quad4layer3[i]=quad4random[i]+number;
		cout<<quad4layer3[i]<<" ";
	}
	int resultLayer3[2][num][num];
	for(i=0;i<num;i++)//loop to store layer 2 in another array
	{
		for(j=0;j<num;j++)
		{
			resultLayer3[2][i][j]=2;
		}
	}
	cout<<endl;
	for(i=0;i<num;i++)//printing the final layer 3
	{
		for(j=0;j<num;j++)
		{
			cout<<resultLayer3[2][i][j]<<" ";
		}
		cout<<endl;
	}
}
