/* Muhammad Rehan Tariq 
	23I-0034
	AI-A
*/
#include<iostream>
#include<cstdlib>
#include<ctime>
using namespace std;
int main()
{
	int array[60],maxValue=10,minValue=-10,totalProfit=0,maximumProfit=0,startIndex=0,endIndex=0,startingIndex;
	unsigned seed=time(0);
	srand(seed);
	for(int i=0;i<=60;i++)
	{
		array[i]=(rand()%(maxValue-minValue+1))+minValue;// generating the random numbers and storing in the array
	}
	for(int i=0;i<60;i++)//printing the whole loop
	{
		cout<<array[i]<<" ";
	}
	
	for(int i=0;i<60;i++)// loop to check the whole array
	{	
		if(array[i]<totalProfit+array[i])// to check that the profit is less than the previous index
		{
			totalProfit+=array[i];
		}
		else// the total profit is equal to that value and the starting index will be changed
		{
			totalProfit=array[i];
			startIndex=i;
		}
		if(totalProfit>maximumProfit)// existing profit check
		{
			maximumProfit=totalProfit;
			startingIndex=startIndex;
			endIndex=i;//end index as the iterator value
		}

	}
	cout<<"\n The Profit earned is: "<<maximumProfit;
	cout<<" \n The starting Day is: "<<startingIndex+1;//+1 is to print the day 
	cout<<" \n The ending day is: "<<endIndex+1;
}
