/* Muhammad Rehan Tariq 
	23I-0034
	AI-A
*/
#include<iostream>
#include<cstdlib>
#include<ctime>
using namespace std;
int main()
{	char c[25][25],a=18,b=12,d=10,e=6,g=13,f=22;
	char ch = 'd';
	int count=1,maxValue=3,minValue=0; 
	for(int i=0;i<25;i++)
	{
		for(int j=0;j<25;j++)
		{	if(j==0 || j==24 || i==0 || i==24)//for the outside boundary
				c[i][j]='#';
			else if ((i==4 || i==3) && ((j>2 && j<9) ||(j>15 && j<22)))// for the fourth and fifth row
				c[i][j]='#';
			else if(((i>=8 && i<=16)&&(j==4 || j==20)) || ((i==8) && (j>=8 && j<=16))||(i>=8 && i<=13)&& (j==12) ||((i==12) &&((j>=4 && j<=9)|| (j>14 && j<20))))// for the middle 
				c[i][j]='#';
			else if ((i==16) && ((j>=8 && j<=10) || (j>=14 && j<=16)))// printing the two rows on the left and right side of the box
				c[i][j]='#';
			else if(((i==20 ||i==21) &&((j>=3 && j<=6) || (j>=18 && j<=21))) ||((i>=16 && i<=21) && (j==8 || j==16)) || ((i==21) && (j>=8 && j<=16))) // printng the box
				c[i][j]='#';
			else if (i==a && j==b)
				c[i][j]='>';
			else if((i==d && j==e) || (i==g && j==f))// doing for single dot only 
				c[i][j]='8';
			else //printing the dots 
				c[i][j]='.';
		}
	}
	do
	{	int check1=0,check2=0;
		bool check3=false;
		if((a==d && b==e ) ||(a==g && b==f))
		{
			break;
		}
		if(count==424)
		{	cout<<"\n All dots are covered";
			break;
		}
		for(int i=0;i>=0;i++)
		{
		int ghost1,ghost2;	
			unsigned seed=time(0);
			srand(seed);
			ghost1 =rand()% 4;
			if(ghost1==0)// 0 for up move
					{	if(c[d+1][e]=='#')
						{
							check1=1;		
						}
						else if(c[d+1][e]=='.')
						{
							check3=true;
							c[d][e]='.';
							c[d+1][e]='8';
							d++;
						}
						else
						{
							c[d][e]='.';
							c[d+1][e]='8';
							d++;
						}
					}
				else if(ghost1==1)// 1 for down move
				{
					if(c[d-1][e]=='#')
					{
						check1=1;
					}
					else if (c[d-1][e]=='.')
					{
						check3=true;
						c[d][e]='.';
						c[d-1][e]='8';
						d--;
					}
					else
					{
						c[d][e]=' ';
						c[d-1][e]='8';
						d--;
					}
				}
				else if(ghost1==2)// for right move
				{	if(c[d][e+1]=='#')
					{
						check1=1;
					}
					else if (c[d][e+1]=='.')
					{
						check3=true;
						c[d][e]='.';
						c[d][e+1]='8';
						e++;
					}
					else
					{	c[d][e]=' ';
						c[d][e+1]='8';
						e++;
					}
				}
				else if(ghost1==3)// for left move
				{
					if(c[d][e-1]=='#')
					{
						check1=1;
					}
					else if (c[d][e-1]=='.')
					{
						check3=true;
						c[d][e]='.';
						c[d][e-1]='8';
						e--;
					}
					else
					{	c[d][e]=' ';
						c[d][e-1]='8';
						e--;
					}
				}
				if(check1==1)// if the ghost 1 hits the wall then the loop will again start
				{
					break;
				}
				ghost2 =rand()%4;// random number
				if(ghost2==0)// Up move
				{	if(c[g+1][f]=='#')
					{
						check2=1;
					}
					else
					{
						if(c[g+1][f]=='.')
						{
							c[g][f]='.';
							c[g+1][f]='8';
							g++;
						}
						else
						{
							c[g][f]='l';
							c[g+1][f]='8';
							g++;
						}
					}
				}
				else if(ghost2==1)// down move
				{
					if(c[g-1][f]=='#')
					{
						check2=1;	
					}
					else
					{
						if(c[g-1][f]=='.')
						{
							c[g][f]='.';
							c[g-1][f]='8';
							g--;
						}
						else
						{
							c[g][f]='l';
							c[g-1][f]='8';
							g--;
						}
					}
				}
				else if(ghost2==2)//Right move
				{	if(c[g][f+1]=='#')
					{
						check2=1;
					}
					else
					{	if(c[g][f+1]=='.')
						{
							c[g][f]='.';
							c[g][f+1]='8';
							f++;
						}
						else
						{
							c[g][f]='l';
							c[g][f+1]='8';
							f++;
						}
					}
				}
				else if( ghost2=3)// left move
				{
					if(c[g][f-1]=='#')
					{
						check2=1;
					}
					else
					{	if(c[g][f-1]=='.')
						{
							c[g][f]='.';
							c[g][f-1]='8';
							f--;
						}
						else
						{
							c[g][f]='l';
							c[g][f-1]='8';
							f--;
						}
					}
				}
				if(check2==1)// check 2 is if ghost2 hits the wall then ghost 1 moves baack 
				{
					switch(ghost1)
					{
						case 0:
						{
							if(check3==true)
								c[d][e]=' ';
							else
								c[d][e]='.';
							c[d-1][e]='8';
							d--;
							break;
						}
						case 1:
						{
							if(check3==true)
								c[d][e]=' ';
							else
								c[d][e]='.';
							c[d+1][e]='8';
							d++;
							break;
						}
						case 2:
						{
							if(check3==true)
								c[d][e]=' ';
							else
								c[d][e]='.';
							c[d][e-1]='8';
							e--;
							break;
						}
						case 3:
						{
							if(check3==true)
								c[d][e]=' ';
							else
								c[d][e]='.';
							c[d][e+1]='8';
							e++;
							break;
							
						}
					
					}
					break;
				}
				// for the postion of pacman
				cout<<"Enter a to move left , \n d to move right \n w to move up \n s to move down:  "<<endl;
				cin>>ch;			
				if(ch=='s')
				{	if(c[a+1][b]=='#') //checking the next array in row that if it's equal to this then it will continue || c[a][b]=='#')
					{
						continue;
					}
					else
					{	if(c[a+1][b]=='.')
						{	
							count++;
						}
						c[a][b]=' ';// declaring the previous place of pacman as space 
						c[a+1][b]='v'; // moving the pacman 
						a++;
					}
				}
				else if (ch=='w')
				{	if(c[a-1][b]=='#')// Checking the previous array in row that if it's equal to this then it will continue 
					{
						continue;
					}
					else
					{	if(c[a-1][b]=='.')
						{	
							count++;
						}
						c[a][b]=' ';// declaring the previous place of pacman as space 
						c[a-1][b]='^';// moving the pacman 
						a--;
					}
				}
				else if(ch=='d')
				{	if(c[a][b+1]=='#')// Checking that the next  array in column  that if it's equal to this then it will continue
					{
						continue;
					}
					else
					{	if(c[a][b+1]=='.')
						{	
							count++;
						}
						c[a][b]=' ';// declaring the previous place of pacman as space 
						c[a][b+1]='>'; // moving the pacman 
						b++;
					}
				}
				else if(ch=='a')
				{	if(c[a][b-1]=='#')// Checking the previous array in column that if it's equal to this then it will continue
					{	
						continue;
					}
					else
					{	if(c[a][b-1]=='.')
						{	
							count++;
						}
						c[a][b]=' ';// declaring the previous place of pacman as space 
						c[a][b-1]='<';// moving the pacman 
						b--;// it is for the next move of pacman 
					}
				}
				else
				{
					cout<<"Inserted character isn't valid "<<endl;
					continue;
				}
				if((a==d && b==e ) ||(a==g && b==f))
				{	
					cout<<"Game Over "<<endl;
					c[a][b]='8';
					for(int k=0;k<25;k++)// showing the last movement  
				{	for(int l=0;l<25;l++)
					{
						cout<<c[k][l]<<" ";
					}
					cout<<endl;
				}
					break;
				}
				for(int k=0;k<25;k++)// showing the overall movement  
				{	for(int l=0;l<25;l++)
					{
						cout<<c[k][l]<<" ";
					}
					cout<<endl;
				}	
			}
		}while(true);
}
