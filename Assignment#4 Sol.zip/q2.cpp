/* Muhammad Rehan Tariq 
	23I-0034
	AI-A
*/
#include<iostream>
#include<cstdlib>
#include<ctime>
using namespace std;
int main()
{
	int rowsize,columnsize;
	cout<<"Enter the rows: ";
	cin>>rowsize;
	cout<<"Enter columns: ";
	cin>>columnsize;
	int array[rowsize][columnsize];
	srand(time(0));
	for(int i=0;i<rowsize;i++)// filling the randomly generated numbers in array
	{
		for(int j=0;j<columnsize;j++)
		{
			array[i][j]=rand()%9;//generating the random numbers
		}
		
	}
	for(int i=0;i<rowsize;i++)
	{
		for(int j=0;j<columnsize;j++)
		{
			cout<<array[i][j]<<" ";
		}
		cout<<endl;
	}
	cout<<"The result is give below: "<<endl;
	int k=0,l=0,i=0,j=0;// loop variables
	int rowIst=0,rowLast=rowsize,columnIst=0,columnLast=columnsize;// variables to stores the indexes
	while(rowIst<rowLast && columnIst<columnLast)
	{
		for(i=columnIst;i<columnLast;i++)// for printing the rows
		{
			cout<<array[rowIst][i]<<" ";
		}
		rowIst++;//as the rows going filled it were removed
		i--;// removing the last iteration of loop
		for(j=rowIst;j<rowLast;j++)//for printing the columns
		{
			cout<<array[j][i] <<" ";
		}
		columnLast--;//the column that is going to filled removed 
		j--;// removing the last iteration of loop
		for(k=columnLast-1;k>columnIst-1;k--)// for print the the last rows
		{
			cout<<array[j][k]<<" ";
		}
		rowLast--;//as the rows going filled it were removed
		k++;// removing the last iteration of loop
		for(l=rowLast-1;l>rowIst-1;l--)//for printing the last column
		{
			cout<<array[l][k]<<" ";
		}
		columnIst++;//the column that is going to filled removed 
	}
			
}
