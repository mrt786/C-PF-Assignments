/* Muhammad Rehan Tariq
	23I-0034
	Assignment#3*/
#include<iostream>
using namespace std;
#include<iomanip>
int main()
{
	int	year,choice,day1=0,month,monthDays=0,totalDays=0,spaces=0,count=0;
	do{	totalDays=0,day1=0,count=0;
		cout<<"enter year greater than 1899: ";
		cin>>year;
		if(year<1900)//input validation
		{	cout<<"\nEntered year is not greater than 1899";
		    continue;
		}
		else
		{
			cout<<"Enter month of the year[1-12]: ";
			cin>>month;
			if(month<0 || month>12)//validating the input
			{	cout<<"\nEntered month is not in the range";
			    continue;
			}
			else
			{	int j=1900;
				while(j<year)//calculating the total days before year
				{	if((j%4==0 && year%100!=0)|| (j%400==0))//checking leap year if yes then year has 366 days 
					{	totalDays=totalDays+366;
						j++;
					}
					else// other wise the days in year is 365
					{	totalDays=totalDays+365;
						j++;
					}
				}
				int k=1;
				while(k<=month)//loop to calculate the total days in that month + from the starting of calendar
				{	if(k==1 || k==3 || k==5 ||k==7 || k==8 || k==10 ||k ==12 )//check for those month having days 31
					{	totalDays=totalDays+31;
						monthDays=31;
						k++;
					}
					else if(k==2)//check for leap year
					{	if((k%4==0 && year%100!=0)|| (k%400==0))
						{
							totalDays=totalDays+29;
							monthDays=29;
							k++;
						}
						else 
						{
								totalDays=totalDays+28;
								monthDays=28;
								k++;
						}
					}
					else//those month having days 30
					{
						totalDays=totalDays+30;
						monthDays=30;
						k++;
					}
				}
					cout<<endl<<setw(13)<<"\t\t\t"<<month<<","<<year<<endl<<endl;
					cout<<setw(13)<<"MON \t"<<"TUES\t"<<"WED \t"<<"THURS\t"<<"FRI \t"<<"SAT \t"<<"SUN"<<endl<<endl<<setw(10);
					if(year==1900 && month==1)// from the starting of calendar there is no spaces i.e starts form monday
					{
					    day1=0;
					}
					else
					{	totalDays=totalDays-monthDays;//finding the total days before that month
						if(year>1904)
						{	totalDays-=1;
						}
	    				day1=totalDays%7;// variable to store the result to add appropriate spaces before the start of month
					}
						for(int i=1;i<=day1;i++)// loop to give spaces 
						{	cout<<"\t";
						    spaces++;
						    if(spaces==7)
						    	cout<<endl;
						}
						for(int j=1;j<=monthDays;j++)//loop to print days 
						{	cout<<j<<"\t";
						    spaces++;
							if(spaces%7==0 || spaces%8==0)
							{
							    cout<<endl<<endl<<setw(10);
							    spaces=0;
							}
						}
				spaces=0;
		}	}
		cout<<endl<<endl<<" If you donot want to print again enter 0:";
		cin>>choice;
	}while(choice);
}
