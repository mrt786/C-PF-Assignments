/* Muhammad Rehan Tariq
	23I-0034
	Assignment#3*/
#include<iostream>
#include<iomanip>
using namespace std;
int main()
{	char square1='1',square2='2',square3='3',square4='4',square5='5',square6='6',square7='7',square8='8',square9='9';
	int moves=0,user1,user2;
	bool gameEnd=false;
		// Printing the game 
	cout<<setw(10)<<"  "<<square1<<"  "<<"|"<<"  "<<square2<<"  "<<"|"<<"  "<<square3<<"  "<<"|"<<endl<<setw(10);
	for(int i=1;i<=18;i++)
	{
		cout<<"-";
	}
	cout<<endl;
	cout<<setw(10)<<"  "<<square4<<"  "<<"|"<<"  "<<square5<<"  "<<"|"<<"  "<<square6<<"  "<<"|"<<endl<<setw(10);
		for(int i=1;i<=18;i++)
	{
		cout<<"-";
	}
	cout<<endl;
	cout<<setw(10)<<"  "<<square7<<"  "<<"|"<<"  "<<square8<<"  "<<"|"<<"  "<<square9<<"  "<<"|"<<endl<<endl<<endl;
	
		
	for(;!gameEnd;)//loop will terminate when gameEnd value is true
	{	cout<<"Player 1 your mark is x Enter your move as square number range [1-9]: ";
		cin>>user1;
		if(user1<1 || user1>9)//if user enters a number that is out of range program will not print that value and prompt the user to re-enter input
		{	
			cout<<"Player 1 your move is not in the range[1-9] \n";
			continue;
		}
		else
		{
			switch(user1)//checking this condition (square1=='x' || square1=='o') on every case if that true in any program will get a new input from user
			{	case 1:
					if(square1=='x' || square1=='o')
					{
						cout<<"You entered a number that is already choosen \n";
						continue;
					}
					else
					{
						square1='x';
						break;
					}
				case 2:
					if(square2=='x' || square2=='o')
					{
						cout<<"You entered a number that is already choosen \n";
						continue;
					}
					else
					{
						square2='x';
						break;
					}
				case 3:
					if(square3=='x' || square3=='o')
					{
						cout<<"You entered a number that is already choosen \n";
						continue;
					}
					else
					{
						square3='x';
						break;
					}
				case 4:
					if(square4=='x' || square4=='o')
					{
						cout<<"You entered a number that is already choosen \n";
						continue;
					}
					else
					{
						square4='x';
						break;
					}
				case 5:
					if(square5=='x' || square5=='o')
					{
						cout<<"You entered a number that is already choosen \n";
						continue;
					}
					else
					{
						square5='x';
						break;
					}
				case 6:
					if(square6=='x' || square6=='o')
					{
						cout<<"You entered a number that is already choosen \n";
						continue;
					}
					else
					{
						square6='x';
						break;
					}
				case 7:
					if(square7=='x' || square7=='o')
					{
						cout<<"You entered a number that is already choosen \n";
						continue;
					}
					else
					{
						square7='x';
						break;
					}
				case 8:
					if(square8=='x' || square8=='o')
					{
						cout<<"You entered a number that is already choosen \n";
						continue;
					}
					else
					{
						square8='x';
						break;
					}
				case 9:
					if(square9=='x' || square9=='o')
					{
						cout<<"You entered a number that is already choosen \n";
						continue;
					}
					else
					{
						square9='x';
						break;
					}
			}
			//printing the updated game board
			cout<<setw(10)<<"  "<<square1<<"  "<<"|"<<"  "<<square2<<"  "<<"|"<<"  "<<square3<<"  "<<"|"<<endl<<setw(10);
				for(int i=1;i<18;i++)
				{
					cout<<"-";
				}
				cout<<endl;
				cout<<setw(10)<<"  "<<square4<<"  "<<"|"<<"  "<<square5<<"  "<<"|"<<"  "<<square6<<"  "<<"|"<<endl<<setw(10);
					for(int i=1;i<=18;i++)
				{
					cout<<"-";
				}
				cout<<endl;
				cout<<setw(10)<<"  "<<square7<<"  "<<"|"<<"  "<<square8<<"  "<<"|"<<"  "<<square9<<"  "<<"|"<<endl<<endl<<endl;
				moves=moves+1;
				if(moves<5)// if the moves are less than 5 than there is a possibility of user to will
				{
					if((square1=='x' && square2=='x' && square3=='x')||(square4=='x' && square5=='x' && square6=='x') || (square7=='x' && square8=='x' && square9=='x') || (square1=='x' && square4=='x' && square7=='x') || (square2=='x' && square5=='x' && square8=='x') ||(square3=='x' && square6=='x' && square9=='x')||(square1=='x' && square5=='x' && square9=='x')||(square3=='x' && square5=='x' && square7=='x'))
					{	
						cout<<"Player 1 win whose mark is: x";
						break;
					}
				}
				else //if in 5 moves it not wins than the game will draw
				{	cout<<"Game draw";
					gameEnd=true;
					continue;
				}
		cout<<"Player 2 your mark is o Enter your move as square number range[1-9]: ";
		cin>>user2;
		if(user2<1 || user2>9)//if user enters a number that is out of range program will not print that value and prompt the user to re-enter input
		{	
			cout<<"Player 2 Your move is not in the range[1-9]";
			continue;
		}
		else
		{
			switch(user2)//if user enters a number that is out of range program will not print that value and prompt the user to re-enter input
			{	case 1:
					if(square1=='x' || square1=='o')
						{
							cout<<"You chose number 1 that is already filled";
							continue;
						}
						else
						{
							square1='o';
							break;
						}
				case 2:
					if(square2=='x' || square2=='o')
					{
						cout<<"You entered a number that is already choosen \n";
						continue;
					}
					else
					{
						square2='o';
						break;
					}
				case 3:
					if(square3=='x' || square3=='o')
					{
						cout<<"You entered a number that is already choosen \n";
						continue;
					}
					else
					{
						square3='o';
						break;
					}
				case 4:
					if(square4=='x' || square4=='o')
					{
						cout<<"You entered a number that is already choosen \n";
						continue;
					}
					else
					{
						square4='o';
						break;
					}
				case 5:
					if(square5=='x' || square5=='o')
					{
						cout<<"You entered a number that is already choosen \n";
						continue;
					}
					else
					{
						square5='o';
						break;
					}
				case 6:
					if(square6=='x' || square6=='o')
					{
						cout<<"You entered a number that is already choosen \n";
						continue;
					}
					else
					{
						square6='o';
						break;
					}
				case 7:
					if(square7=='x' || square7=='o')
					{
						cout<<"You entered a number that is already choosen \n";
						continue;
					}
					else
					{
						square7='o';
						break;
					}
				case 8:
					if(square8=='x' || square8=='o')
					{
						cout<<"You entered a number that is already choosen \n";
						continue;
					}
					else
					{
						square8='o';
						break;
					}
				case 9:
					if(square9=='x' || square9=='o')
					{
						cout<<"You entered a number that is already choosen \n";
						continue;
					}
					else
					{
						square9='o';
						break;
					}
			}
			//Printing the update gameboard
			cout<<setw(10)<<"  "<<square1<<"  "<<"|"<<"  "<<square2<<"  "<<"|"<<"  "<<square3<<"  "<<"|"<<endl<<setw(10);
			for(int i=1;i<18;i++)
			{
				cout<<"-";
			}
			cout<<endl;
			cout<<setw(10)<<"  "<<square4<<"  "<<"|"<<"  "<<square5<<"  "<<"|"<<"  "<<square6<<"  "<<"|"<<endl<<setw(10);
				for(int i=1;i<=18;i++)
			{
				cout<<"-";
			}
		}
		cout<<endl;
		cout<<setw(10)<<"  "<<square7<<"  "<<"|"<<"  "<<square8<<"  "<<"|"<<"  "<<square9<<"  "<<"|"<<endl<<endl<<endl;
			// Check is for player 2  if wins
			if((square1=='o' && square2=='o' && square3=='o')||(square4=='o' && square5=='o' && square6=='o') || (square7=='o' && square8=='o' && square9=='o') || (square1=='o' && square4=='o' && square7=='o') || (square2=='o' && square5=='o' && square8=='o') ||(square3=='o' && square6=='o' && square9=='o')||(square1=='o' && square5=='o' && square9=='o')||(square3=='o' && square5=='o' && square7=='o'))
			{	
				cout<<"Player 2 win whose mark is: o";
				gameEnd=true;
				break;
			}
		
		}
	}
}
