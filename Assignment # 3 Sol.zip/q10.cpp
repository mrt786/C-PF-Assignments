/* Muhammad Rehan Tariq
	23I-0034
	Assignment#3*/
#include<iostream>
using namespace std;
int main()
{	int numberOfRows,number=11,loop1Variable,sum=0,product=1;
	cout<<"Enter number of rows greater than zero : ";
	cin>>numberOfRows;
	if(numberOfRows<=0)//input validation
	cout<<"Entered number of rows aren't greater than zero";
	else
	{
		for(loop1Variable=0;loop1Variable<=numberOfRows;loop1Variable++)//loop to print the triangle to entered rows
		{
				for(int loop2Variable=0;loop2Variable<=numberOfRows-loop1Variable-1;loop2Variable++)//loop for spacing from left side
				{
					cout<<"  ";
				}
				int result=1;
				int loop3Variable=1;
				while(loop3Variable<=loop1Variable)//loop to print the values
				{
					cout<<result<<"   ";
					result=result*(loop1Variable-loop3Variable);
					result=result/loop3Variable;
					sum=sum+result;
					if(result>0)
					{
					product=product*result;
					}
					loop3Variable++;
				}
				cout<<endl;
		}
		cout<<"The Sum of pascal's Triangle is: "<<sum;
		cout<<"\nThe product of pascal's triangle is: "<<product;
	}
}
