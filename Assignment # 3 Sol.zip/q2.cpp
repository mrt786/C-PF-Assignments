/* Muhammad Rehan Tariq
	23I-0034
	Assignment#3*/
#include<iostream>
using namespace std;
int main(){
	int number,j=0,i=0,l=0,m=0;
	cout<<"Enter a number:";
	cin>>number;
	if(number>0)
	{
		for( i=0;i<=number;i++)
		{
			for( j=1;j<((number*2)+1);j++)
			{
				if(j<(number+1))
				{	for(int m=1; m<number-i+1;m++)
					{
						cout<<" ";
						j++;
					}
				for(int o=1;o<=i;o++)
					{	cout<<"\\";
						j++;
					}
				}
				if(j==(number+1))
				{	cout<<"|";
					for(l=0;l<i;l++)
					{	cout<<"/";
					}
				}
			}
			cout<<endl;
		}
			int result=number/3;
				if(result%2!=0)// number is odd
				{	for(int i=0;i<3;i++)
					{	for(int j=0;j<number-1;j++)
						{
								cout<<" ";
						}
						for(int k=0; k<2;k++)
						{	cout<<"|";
						}
						cout<<endl;
					}
					// for the last line of the stem
					for(int i=0;i<2;i++)
					{	cout<<" ";
					}
					cout<<"_";
					for(int k=0; k<result;k++)
						{	cout<<"|";
						}
						cout<<"_";	
				}
				else// number is even
				
				{	result+=1;
					for(int i=0;i<4;i++)
					{	for(int j=0;j<number-1;j++)
						{
								cout<<" ";
						}
						for(int k=0; k<3;k++)
						{	cout<<"|";
						}
						cout<<endl;
					}
					//for the last line of stem
					for(int i=0;i<number-2;i++)
					{	cout<<" ";
					}
					cout<<"_";
					for(int k=0; k<3;k++)
						{	cout<<"|";
						}
						cout<<"_";	
				}	
		return 0;
	}
	else
		cout<<"Invalid Input";
}
