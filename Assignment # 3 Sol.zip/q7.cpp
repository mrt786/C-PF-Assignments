/* Muhammad Rehan Tariq
	23I-0034
	Assignment#3*/
#include<iostream>
#include<iomanip>
using namespace std;
int main()
{	int loop1,r;
	//  for printing the upper half
	for( r=1; r<=5;r++)
	{	for(loop1=1;loop1<=67;loop1++)
		{	cout<<" ";
			if(r==1)//row one it is same and has no other thing to print
			{ if(loop1==32)
				{
					cout<<"\\"<<r<<"/";
					loop1=loop1+3;//incrementing here three times as there are three characters 
				}
			}
			if(r>1)
			{	if(loop1==33-((r-1)*6)-2)
				{	
					cout<<"\\"<<r;
					loop1=loop1+2;//incrementing here two times as there are two characters 
				}
				if(loop1==33+((r-1)*6)+1)
				{	
					cout<<r<<"/";
					loop1=loop1+2;//incrementing here two times as there are two characters 
				}
			}
		}
		cout<<endl;
	}
	// Printing the middle of the program
	for(int rows=1;rows<=9;rows++)
	{	cout<<"|*";
		for(int j=0;j<=4;j++)//printing the spaces the begining
		{	cout<<" ";
		}
		
			if(rows==1 || rows==9)//they have same patteren only difference is of v and ^
			{	cout<<" ";
				for(int k=0;k<51;k++)
				{	rows==1?cout<<"^":cout<<"v";
				}
				cout<<" ";
			}
			if(rows>1 && rows <9)
			{	cout<<"<";
				cout<<"     ";
				for(int l=0;l<59;l++)
				{	if(l==0)
					{
						cout<<"*";
					}
					if(rows==2 || rows==5)
					{	if(l<23)
						{
							cout<<"*";
							l++;
						}
						if(l==23)
						{	cout<<"*";
							l++;
						}
						if(l>24)
						{	if(l<38)
							{	for(int i=0;i<3;i++)
							{
								cout<<" ";
								l++;
							}
							}
							else 
							{
								for(int i=0;i<4;i++)
								{
									cout<<"*";
									l++;
								}
								if(l==60)
								{	cout<<" ";
								}
							}
						}
					
					}
					else if(rows==3 || rows==4)
					{	if(l<23)
						{
							cout<<" ";
							l++;
						}
						if(l==23)
						{	cout<<"*";
							l++;
						}	
						if(l>25)
						{	if(l<36)
							{
								cout<<" ";
								l++;
							}
							if(l==36)
							{	rows==3?cout<<" ":cout<<"o";
								l++;
							}
							if(l<=44)
							{	
								cout<<" ";
								l++;
							}
							if(l>=45)
							{
								if(l==45)
								{	cout<<"*";
									l++;
								}
								else
								{	for(int i=0;i< 8;i++)
									{
										cout<<" ";
										l++;
									}
								}
							}
						}
					}
					else //if(rows==6||rows==7||rows==8)
					{	if(l<=50)
						{
							l==50?cout<<"*":cout<<" ";
							l++;
						}
						else
						{	 for(int i=0;i<4;i++)
							{	cout<<" ";
							}
							l++;
						}
					}
				}
				cout<<"   ";
				cout<<">";
			}
			
		for(int j=1;j<7;j++) //printing the spaces at the end
		{	cout<<" ";
			}
		cout<<"*|"<<endl;
	}
	// For printing the lower half
	for(r=5; r>=1;r--)
	{	for(int loop3=1;loop3<=67;loop3++)
		{	cout<<" ";
			if(r>1)
			{	if(loop3==33-((r-1)*6)-2)
				{	
					cout<<"\\"<<r;
					loop3=loop3+2;//incrementing here two times as there are two characters 
				}
				if(loop3==33+((r-1)*6)+1)
				{	
					cout<<r<<"/";
					loop3=loop3+2;//incrementing here two times as there are two characters 
				}
			}
					if(r==1)//last row has nothing else to print other than that
					{	 if(loop3==32)
						{
						cout<<"\\"<<r<<"/";//incrementing here three times as there are three characters 
						loop3=loop3+3;
						}
					}
		}
		cout<<endl;
	}
}
