/* Muhammad Rehan Tariq
	23I-0034
	Assignment#3*/
#include<iostream>
using namespace std;
int main()
{
	long int baseNumber,number;
	int remainder;
	char Remainder,ch='0',character='A';
	string result=" ";
	cout<<"Enter a positive number in the range of [1 - 9223372036854775807] =";
	cin>>number;
	if(number>=1 && number<=4294967295)
	{
		
			cout<<"Enter the base you wanna convert your number range [2-16]:";
			cin>>baseNumber;
			if(baseNumber>=2 || baseNumber<=16)
			{
				while(number>0)
				{	
						remainder=number%baseNumber;
						if(remainder>=10)
						{	
							Remainder=(char)(remainder-10+character);//type casting integer to charcter here character variable stores A
						}
						else
						{
							Remainder=((char)remainder+ch);//type casting integer to character ch store 
						}
						result=Remainder+result;
						number/=baseNumber;
				}
				cout<<"Result after conversion your decimal number into base "<<baseNumber<< " is :"<<result;
			}
			else
			{	cout<<"The base is not in the range";
			}
	}
	else 
	cout<<"Entered number isn't in the range";
}
