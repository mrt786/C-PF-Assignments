/* Muhammad Rehan Tariq
	23I-0034
	Assignment#3*/
#include<iostream>
using namespace std;
int main()
{	int inputNum,i=0,first=0,second=1,fibbonacci=0,count=0;
	cout<<"Enter a positive number : ";
	cin>>inputNum;
	if(inputNum<0)//validating the input
		cout<<"Entered number is not positive";
	else
	{	while(i<inputNum)//loop will run until it is less then the entered number
		{
            first=second;
            second=i;
            i=first+second;
			if(i<=8)
			{
			   
				fibbonacci=fibbonacci*10+i;
			}
			if(i>8)
			{
				fibbonacci=fibbonacci*100+i;
			}
		}
		if(i>inputNum)// if number is not fibbonacci
			cout<<"Enter number doesnot lies in fibonacci series ";
		else
		{	
			cout<<"Number: "<<fibbonacci<<endl;
		}
		
	}
			
}
