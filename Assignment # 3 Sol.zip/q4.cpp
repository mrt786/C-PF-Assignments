/* Muhammad Rehan Tariq
	23I-0034
	Assignment#3*/
#include<iostream>
using namespace std;
int main()
{	int people,steps,result=0;
	cout<<"Enter number of people greater than 1: ";
	cin>>people;
	if(people<1)
		cout<<"Enter number of people greater than 1 ";
	else
	{
		cout<<"Enter step greater than zero :";
		cin>>steps;
		if(steps<0)
		{	cout<<"Invalid Steps";
		}
		else
		{	int i=1;
			while(i<=people)
			{	
				result=(result+steps);
				result=result%i;
				i++;
			}
			result++;
			cout<<"Last person is standing at postion : "<<result;
		}
	}
}
