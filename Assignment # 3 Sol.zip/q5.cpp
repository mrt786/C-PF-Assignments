/* Muhammad Rehan Tariq
	23I-0034
	Assignment#3*/
#include<iostream>
using namespace std;
int main()
{	int number;
	cout<<"Enter a positive number:";
	cin>>number;
	if(number>1)//taking positive numbers only
		for(int loop1Variable=0;loop1Variable<number;loop1Variable++)
		{	for(int loop2Variable=1;loop2Variable<=number;loop2Variable++)
			{	int count=0,checkNumber;
				if(loop1Variable==0)//if is for the first row of the program
				{
				for(int loop3Variable=loop2Variable;loop3Variable>0;loop3Variable--)
				{	checkNumber= loop2Variable;
					if(checkNumber%loop3Variable==0)//number is prime 
					{	
						count++;
					}
				}
				if(count==1 || count==2)//count is 1 for 1 and 2 for 2,3
				{
					cout<<"P\t";
				}
				else
				{
					cout<<"-\t";
				}
				}
				else// else is for numbers other than the fisrt row
				{	for(int loop3Variable=(((number*loop1Variable)+loop2Variable));loop3Variable>0;loop3Variable--)
					{	checkNumber= ((number*loop1Variable)+loop2Variable);
						if(checkNumber%loop3Variable==0)//number is prime 
						{	
							count++;
						}
					}
						if( count==2)
					{
						cout<<"P\t";
					}
					else
					{
						cout<<"-\t";
					}
				}
			}
			cout<<endl;
		}
	else
		cout<<"Enter positive numbers only";
}
