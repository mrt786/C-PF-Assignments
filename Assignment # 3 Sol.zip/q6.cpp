/* Muhammad Rehan Tariq
	23I-0034
	Assignment#3*/
#include<iostream>
using namespace std;
int main()
{	int terms,loop1Variable,loop2Variable,loop3Variable;
	unsigned long long factorial=1;
	double long result=0,valueX,quotient,x;
	cout<<"To how many terms you wanna print the series Enter a positive number greater than zero: ";
	cin>>terms;
	if(terms>0)//terms cannot be negative
	{	cout<<"enter the value of x: ";
		if(cin>>x)// input validation
		{	valueX=x;
			for(loop1Variable=1;loop1Variable<=terms;loop1Variable=loop1Variable+2)
			{	x=valueX;
				x=x*3.14;
				x=x/180;
				factorial=1;
				for(loop2Variable=1;loop2Variable<=loop1Variable;loop2Variable++)
				{	if(loop2Variable>1)
					{
						x=x*x;
					}
				}
				for(loop3Variable=loop2Variable-1;loop3Variable>1;loop3Variable--)
					{
					factorial=factorial*loop3Variable;
					
					}
				quotient=x/factorial;
				if((loop1Variable-1)%4==0)//dividing this into two parts which one has to add and subtract. This if is for adding into result
				{
					result=result+quotient;
				}
				else //else is for subtracting from result
				{
					result=result-quotient;
				}
			}
			cout<<"The result of maclaurin series of "<<terms<<" terms at x= "<<valueX<<" is = "<<result;	
		}
			
		else
			cout<<"value of x is not a number";
	}
	else
		cout<<"Enter positive number greater than zero";
	return 0;
}
