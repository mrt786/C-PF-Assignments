/* 	NAME:	Muhammad Rehan Tariq
	ID:	23I-0034
	ASSITGNMENST#2
*/
#include<iostream>
#include<cmath>
using namespace std;
int main()
{	float i,u=1.234,p=3.334;
	double result;
	cout<<"Enter the value of i:";
	cin>>i;
	if(i>=1)
	{
		result=u*sqrt(i*i*i);//breaking the formula into smaller steps
		result=result*((i*i)-1);
		result=sqrt(result);
		result=result/(sqrt((p*i)-2)+(sqrt((p*i)-2)));
		cout<<"\n the result of the formula is:"<<result;
	}
	else
		cout<<"\n The result of formula is Imagianry";
}
