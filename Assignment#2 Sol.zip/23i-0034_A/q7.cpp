/* 	NAME:	Muhammad Rehan Tariq
	ID:	23I-0034
		ASSITGNMENST#2
*/
#include<iostream>
using namespace std;
int main()
{ 	int num1,num2;
	string colour1,colour2;
	cout<<"Enter two numbers in the range of [1-81]"<<endl;
	cin>>num1>>num2;
	if((num1>0 && num1<82)&&(num2>0 && num2<82))
	{	if(((num1>=10) && (num1<=18)) || ((num1>=28) && (num1<=36)) || ((num1>=46) && (num1<=54)) || ((num1>=64) && (num1<=72)))
		{	//checking the numbers are in the even row or not
			if(num1%3==0)
				colour1="Grey";
			else if((num1+1)%3==0)
				colour1="Red";
			else 
				colour1="Blue";
		}	
		else 
		{	if(num1%3==0)
				colour1="Red";
			else if(((num1-1)%3==0) && ((num1+2)%3==0))
				colour1="Grey";
			else
				colour1="Blue";
		}
		if(((num2>=10) && (num2<=18)) || ((num2>28) && (num2<=36)) || ((num2>=46) && (num2<=54)) || ((num2>=64) && (num2<=72)))
		{	if(num2%3==0)
				colour2="Grey";
			else if((num2-1)%3==0)
				colour2="Blue";
			else
				colour2="Red";
		}	
		else 
		{	if(num2%3==0)
				colour2="Red";
			else if(((num2-1)%3==0) && ((num2+2)%3==0))
				colour2="Grey";
			else
				colour2="Blue";
			
		}
		if(colour1==colour2)
		{	cout<<"You win"<<endl;
			cout<<colour1;
		}
		else
			cout<<"You lose";
	}
	else
		cout<<"Number is not in range";		
}
