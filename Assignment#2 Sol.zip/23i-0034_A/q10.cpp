/*	NAME:	Muhammad Rehan Tariq
	ID:	23I-0034
	ASSITGNMENST#2
*/
#include<iostream>
#include<cstdlib>
#include<ctime>
using namespace std;
int main()
{	int choice,maxValue,minValue,num1,num2;
	char character;
	cout<<"1.Play Higher or Lower\n2. Play paper - scissors - rock\n3. Guess the numbers\n4. Quit"<<endl;
	cin>>choice;
	unsigned seed=time(0);
	srand(seed);
	switch(choice)
	{	case 1:
			minValue=1;
			maxValue=20;
			num1=(rand()%(maxValue-minValue+1))+minValue;
			num2=(rand()%(maxValue-minValue+1))+minValue;
			cout<<"First Number is:"<<num1;
			cout<<"\nEnter a character H or L:";
			cin>>character;
			if(character=='H' || character=='L')
			{	if(character=='H')
				{	if(num2>num1)
					{	cout<<"you winn";
						cout<<"\nNumber 2 is:"<<num2;
					}
					else
					{	cout<<"you lose";
						cout<<"\nNumber 2 is:"<<num2;
					}				
				}
				else
				{	if(num1>num2)
					{	cout<<"you win";
						cout<<"\nNumber 2 is:"<<num2;
					}
					else
					{	cout<<"you lose";
						cout<<"\nNumber 2 is:"<<num2;				
					}
				}
			}	
			else
				cout<<"\nCharacter is not H or L";
				break;
		case 2:
			maxValue=3,minValue=1;
			int num;
			num=(rand()%(maxValue-minValue+1))+minValue;
			cout<<num;
			if(num==1)
				num=(char)'P';
			else if(num==2)
				num=(char)'S';
			else
				num=(char)'R';
			cout<<"\nEnter a character P for Paper R for Rock and S for Scissors:";
			cin>>character;
			if(character=='P'||character=='R'||character=='S')
			{	if((character=='S'&& num=='P')||((character=='R' && num=='S')|| (character=='P' && num=='R')))
					cout<<"\nYou won";
				else if(character==num)
					cout<<"\n Game draw";
				else
					cout<<"\nYou loose";
			}
			else
				cout<<"\nInvalid Character";
			break;
		case 3:
			int num3,number1,number2,number3;
			maxValue=9,minValue=0;
			num1=(rand()%(maxValue-minValue+1))+minValue;
			num2=(rand()%(maxValue-minValue+1))+minValue;
			num3=(rand()%(maxValue-minValue+1))+minValue;
			cout<<num1<<endl<<num2<<endl<<num3<<endl;
			cout<<"Guess three numbers in the range [0-9]"<<endl;
			cin>>number1>>number2>>number3;
			if(((number1>=0) && (number2>=0) && (number3>=0)) && ((number1<=9)&&(number2<=9)&&(number3<=9)))
			{	if((num1==number1) && (num2==number2) &&(num3==number3))
					cout<<"Three numbers are matching in the exact order";
				else if((num1==number1 || num2==number2 || num3==number3) && ((num1==number2 || num2==number3 || num3==number1) && (num1==number3 || num2==number1 || num3==number2)))
					cout<<" Three numbers are matching but not in order";
				else if((num1==number1 || num1==number2 || num1==number3) && ((num2==number1 || num2==number2 || num2==number3)||(num3==number1 || num3==number2 || num3==number3))) 
					cout<<"Two numbers are matching";
				else if((num1==number1 || num2==number2 || num3==number3) || ((num1==number2 || num2==number3 || num3==number1)||(num1==number3 || num2==number1 || num3==number2)))
					cout<<"only one number is matching";
				else
					cout<<"No mathing of numbers";
			}
			else
				cout<<"\n Guessed Numbers are not in the given range";
			break;
		case 4:
			break;
		default:
			cout<<"\nInvalid Input";
			break;
	}
}
