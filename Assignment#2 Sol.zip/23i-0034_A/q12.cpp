/*	NAME:	Muhammad Rehan Tariq
	ID:	23I-0034
	ASSITGNMENST#2
*/
#include<iostream>
#include<iomanip>
#include<string>
using namespace std;
int main()
{	int ED=0,load=2,oldAcNumber=0,meterNo=123456,previousReadings=9742,electricityDuty=0,presentReadings=9942,mf=1,unitConsumed=0034,electricityCost=680,fuelPriceAdjusment=700,fcSurcharge=90;
	int qtrTarrif=-14,total1,tvFee=35,gst=800,gstOnFpa=108,total2,currentBill,totalFpa=700,payableWithinDate,lpSurcharge=400,payableAfterDate;
	string	connectionDate="28 Dec 11",billMOnth="Oct 21",readingDate="02-Nov-21",issueDate="03-Nov-21",dueDate="17-Nov-21",consumerId="17-04-2023",tarrif="A-1a(01)";
	string division="Westridge",subDivision="Tarnol pesh RD",feederName="Nust Road",referenceNo="23i0034",name,address;
	cout<<"Enter your name\n";
	getline(cin,name);
	cout<<"Enter your address\n";
	getline(cin,address);
	total1=	electricityCost+fuelPriceAdjusment+fcSurcharge+qtrTarrif;
	total2=tvFee+gst+gstOnFpa;
	currentBill=total1+total2;
	payableWithinDate=totalFpa+currentBill;
	payableAfterDate=payableWithinDate+lpSurcharge;

	cout<<" "<<setfill('_')<<setw(149)<<"_"<<endl;

	cout<<"|"<<setfill(' ')<<setw(85)<<"ISLAMABAD ELECTRIC SUPPLY COMPANY"<<setfill(' ')<<setw(65)<<"|"<<endl;

	cout<<"|"<<setfill(' ')<<setw(65)<<"Your better service - our pride"<<setfill(' ')<<setw(45)<<"ELECTRICITY CONSUMER BILL"<<setfill(' ')<<setw(40)<<"www.iesco.com.pk|"<<endl;

	cout<<"|_"<<setfill('_')<<setw(149)<<"_|"<<endl;

	cout<<"|"<<setfill(' ')<<setw(20)<<"CONNECTION DATE"<<setfill(' ')<<setw(4)<<"|"<<setfill(' ')<<setw(20)<<"CONNECTED LOAD"<<setfill(' ')<<setw(4)<<"|"<<setfill(' ')<<setw(9)<<"ED@"<<setfill(' ')<<setw(7)<<"|"<<setfill(' ')<<setw(13)<<"BILL MONTH"<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(16)<<"READING DATE"<<setfill(' ')<<setw(6)<<"|"<<setfill(' ')<<setw(17)<<"ISSUE DATE"<<setfill(' ')<<setw(8)<<"|"<<setfill(' ')<<setw(14)<<"DUE DATE"<<setfill(' ')<<setw(7)<<"|"<<endl;

	cout<<"|_"<<setfill('_')<<setw(149)<<"_|"<<endl;

	cout<<"|"<<setfill(' ')<<setw(20)<<connectionDate<<setfill(' ')<<setw(4)<<"|"<<setfill(' ')<<setw(20)<<" "<<setfill(' ')<<setw(4)<<"|"<<setfill(' ')<<setw(9)<<ED<<setfill(' ')<<setw(7)<<"|"<<setfill(' ')<<setw(13)<<billMOnth<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(16)<<readingDate<<setfill(' ')<<setw(6)<<"|"<<setfill(' ')<<setw(17)<<issueDate<<setfill(' ')<<setw(8)<<"|"<<setfill(' ')<<setw(14)<<dueDate<<setfill(' ')<<setw(7)<<"|"<<endl;

	cout<<"|_"<<setfill('_')<<setw(149)<<"_|"<<endl;

	cout<<"|"<<setfill(' ')<<setw(19)<<"CONSUMER ID"<<setfill(' ')<<setw(6)<<"|"<<setfill(' ')<<setw(13)<<"TARIFF"<<setfill(' ')<<setw(7)<<"|"<<setfill(' ')<<setw(13)<<"LOAD"<<setfill(' ')<<setw(8)<<"|"<<setfill(' ')<<setw(18)<<"OLD A/C NUMBER"<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(15)<<"SUB DIVISION"<<setfill(' ')<<setw(10)<<"|"<<setfill(' ')<<setw(23)<<subDivision<<setfill(' ')<<setw(13)<<"|"<<endl;

	cout<<"|_"<<setfill('_')<<setw(149)<<"_|"<<endl;

	cout<<"|"<<setfill(' ')<<setw(19)<<"REFERENCE NO"<<setfill(' ')<<setw(6)<<"|"<<setfill(' ')<<setw(13)<<"LOCK AGE"<<setfill(' ')<<setw(7)<<"|"<<setfill(' ')<<setw(13)<<"NO of ACs"<<setfill(' ')<<setw(8)<<"|"<<setfill(' ')<<setw(18)<<"UN-BILL-AGE"<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(15)<<"FEEDER NAME"<<setfill(' ')<<setw(10)<<"|"<<setfill(' ')<<setw(23)<<division<<setfill(' ')<<setw(13)<<"|"<<endl;

	cout<<"|_"<<setfill('_')<<setw(149)<<"_|"<<endl;

	cout<<"|"<<setfill(' ')<<setw(19)<<referenceNo<<setfill(' ')<<setw(6)<<"|"<<setfill(' ')<<setw(13)<<" "<<setfill(' ')<<setw(7)<<"|"<<setfill(' ')<<setw(13)<<" "<<setfill(' ')<<setw(8)<<"|"<<setfill(' ')<<setw(18)<<" "<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(23)<<" "<<setfill(' ')<<setw(19)<<"Web Generated Bill"<<setfill(' ')<<setw(19)<<"|"<<endl;

	cout<<"|_"<<setfill('_')<<setw(149)<<"_|"<<endl;

	cout<<"|"<<name<<" "<<address<<setfill(' ')<<setw(76)<<"|"<<setfill(' ')<<setw(7)<<"MONTH"<<setfill(' ')<<setw(18)<<"UNITS"<<setfill(' ')<<setw(15)<<"BILL"<<setfill(' ')<<setw(18)<<"PAYMENTS"<<setfill(' ')<<setw(3)<<"|"<<endl;

	cout<<"|"<<"S/O TARIQ MAHMOOD"<<setfill(' ')<<setw(72)<<"|"<<setfill('_')<<setw(61)<<"|"<<endl;

	cout<<"|"<<"KAHUTA"<<setfill(' ')<<setw(83)<<"|"<<setfill(' ')<<setw(15)<<"|"<<setfill(' ')<<setw(15)<<"|"<<setw(15)<<setfill(' ')<<"|"<<setfill(' ')<<setw(16)<<"|"<<endl;
	cout<<"|"<<"RAWALPINDI"<<setfill(' ')<<setw(79)<<"|"<<setfill(' ')<<setw(15)<<"|"<<setfill(' ')<<setw(15)<<"|"<<setw(15)<<setfill(' ')<<"|"<<setfill(' ')<<setw(16)<<"|"<<endl;

	cout<<"|"<<setfill(' ')<<setw(89)<<"|"<<setfill(' ')<<setw(15)<<"|"<<setfill(' ')<<setw(15)<<"|"<<setw(15)<<setfill(' ')<<"|"<<setfill(' ')<<setw(16)<<"|"<<endl;

	cout<<"|"<<setfill(' ')<<setw(89)<<"|"<<setfill(' ')<<setw(15)<<"|"<<setfill(' ')<<setw(15)<<"|"<<setw(15)<<setfill(' ')<<"|"<<setfill(' ')<<setw(16)<<"|"<<endl;
	cout<<"|"<<setfill('_')<<setw(89)<<"|"<<setfill(' ')<<setw(15)<<"|"<<setfill(' ')<<setw(15)<<"|"<<setw(15)<<setfill(' ')<<"|"<<setfill(' ')<<setw(16)<<"|"<<endl;

	cout<<"|"<<setfill(' ')<<setw(12)<<"METER NO"<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(12)<<"PREVIOUS"<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(11)<<"PRESENT"<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(6)<<"MF"<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(7)<<"UNITS"<<setfill(' ')<<setw(3)<<"|"<<setfill(' ')<<setw(13)<<"STATUS"<<setfill(' ')<<setw(5)<<"|"<<setw(15)<<setfill(' ')<<"|"<<setfill(' ')<<setw(15)<<"|"<<setfill(' ')<<setw(15)<<"|"<<setfill(' ')<<setw(16)<<"|"<<endl;	

	cout<<"|"<<setfill(' ')<<setw(12)<<" "<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(12)<<"READINGS"<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(11)<<"READINGS"<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(6)<<" "<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(7)<<" "<<setfill(' ')<<setw(3)<<"|"<<setfill(' ')<<setw(13)<<" "<<setfill(' ')<<setw(5)<<"|"<<setw(15)<<setfill(' ')<<"|"<<setfill(' ')<<setw(15)<<"|"<<setfill(' ')<<setw(15)<<"|"<<setfill(' ')<<setw(16)<<"|"<<endl;

	cout<<"|_"<<setfill('_')<<setw(16)<<"|"<<setfill('_')<<setw(17)<<"|"<<setfill('_')<<setw(16)<<"|"<<setfill('_')<<setw(11)<<"|"<<setfill('_')<<setw(10)<<"|"<<setfill('_')<<setw(18)<<"|"<<setw(15)<<setfill(' ')<<"|"<<setfill(' ')<<setw(15)<<"|"<<setfill(' ')<<setw(15)<<"|"<<setfill(' ')<<setw(16)<<"|"<<endl;

	cout<<"|"<<setfill(' ')<<setw(12)<<meterNo<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(12)<<previousReadings<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(11)<<presentReadings<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(6)<<mf<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(7)<<unitConsumed<<setfill(' ')<<setw(3)<<"|"<<setfill(' ')<<setw(13)<<" "<<setfill(' ')<<setw(5)<<"|"<<setw(15)<<setfill(' ')<<"|"<<setfill(' ')<<setw(15)<<"|"<<setfill(' ')<<setw(15)<<"|"<<setfill(' ')<<setw(16)<<"|"<<endl;

		cout<<"|"<<setfill(' ')<<setw(12)<<" "<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(12)<<" "<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(11)<<" "<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(6)<<" "<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(7)<<" "<<setfill(' ')<<setw(3)<<"|"<<setfill(' ')<<setw(13)<<" "<<setfill(' ')<<setw(5)<<"|"<<setw(15)<<setfill(' ')<<"|"<<setfill(' ')<<setw(15)<<"|"<<setfill(' ')<<setw(15)<<"|"<<setfill(' ')<<setw(16)<<"|"<<endl;

	cout<<"|"<<setfill(' ')<<setw(12)<<" "<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(12)<<" "<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(11)<<" "<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(6)<<" "<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(7)<<" "<<setfill(' ')<<setw(3)<<"|"<<setfill(' ')<<setw(13)<<" "<<setfill(' ')<<setw(5)<<"|"<<setw(15)<<setfill(' ')<<"|"<<setfill(' ')<<setw(15)<<"|"<<setfill(' ')<<setw(15)<<"|"<<setfill(' ')<<setw(16)<<"|"<<endl;

	cout<<"|"<<setfill(' ')<<setw(12)<<" "<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(12)<<" "<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(11)<<" "<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(6)<<" "<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(7)<<" "<<setfill(' ')<<setw(3)<<"|"<<setfill(' ')<<setw(13)<<" "<<setfill(' ')<<setw(5)<<"|"<<setw(15)<<setfill(' ')<<"|"<<setfill(' ')<<setw(15)<<"|"<<setfill(' ')<<setw(15)<<"|"<<setfill(' ')<<setw(16)<<"|"<<endl;

cout<<"|"<<setfill(' ')<<setw(12)<<" "<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(12)<<" "<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(11)<<" "<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(6)<<" "<<setfill(' ')<<setw(5)<<"|"<<setfill(' ')<<setw(7)<<" "<<setfill(' ')<<setw(3)<<"|"<<setfill(' ')<<setw(13)<<" "<<setfill(' ')<<setw(5)<<"|"<<setw(15)<<setfill(' ')<<"|"<<setfill(' ')<<setw(15)<<"|"<<setfill(' ')<<setw(15)<<"|"<<setfill(' ')<<setw(16)<<"|"<<endl;
		cout<<"|"<<setfill('_')<<setw(89)<<"|"<<setfill('_')<<setw(15)<<"_"<<setfill('_')<<setw(15)<<"_"<<setw(15)<<setfill('_')<<"_"<<setfill('_')<<setw(16)<<"|"<<endl;
	cout<<"|"<<setfill(' ')<<setw(30)<<"IECSO CHARGES"<<setfill(' ')<<setw(17)<<"|"<<setfill(' ')<<setw(28)<<"GOVT CHARGES"<<setfill(' ')<<setw(14)<<"|"<<setfill(' ')<<setw(37)<<"TOTAL CHARGES"<<setfill(' ')<<setw(24)<<"|"<<endl;
cout<<"|"<<setfill('_')<<setw(47)<<"|"<<setfill('_')<<setw(42)<<"|"<<setfill('_')<<setw(61)<<"|"<<endl;
	cout<<"|"<<setfill(' ')<<setw(18)<<"UNITS CONSUMED"<<setfill(' ')<<setw(6)<<"|"<<setfill(' ')<<setw(13)<<unitConsumed<<setfill(' ')<<setw(10)<<"|"<<setfill(' ')<<setw(20)<<"ELECTRICITY DUTY"<<setfill(' ')<<setw(6)<<"|"<<setfill(' ')<<setw(8)<<electricityDuty<<setfill(' ')<<setw(8)<<"|"<<setfill(' ')<<setw(23)<<"ARREAR/AGE"<<setfill(' ')<<setw(12)<<"|"<<setfill(' ')<<setw(26)<<"|"<<endl;
		cout<<"|"<<setfill('_')<<setw(24)<<"|"<<setfill('_')<<setw(23)<<"|"<<setfill('_')<<setw(26)<<"|"<<setfill('_')<<setw(16)<<"|"<<setfill('_')<<setw(35)<<"|"<<setfill('_')<<setw(26)<<"|"<<endl;
	
	cout<<"|"<<setfill(' ')<<setw(21)<<"COST OF ELECTRICITY"<<setw(3)<<"|"<<setw(13)<<electricityCost<<setw(10)<<"|"<<setw(16)<<"TV FEE"<<setw(10)<<"|"<<setw(8)<<tvFee<<setw(8)<<"|"<<setw(23)<<"CURRENT BILL"<<setw(12)<<"|"<<setw(13)<<currentBill<<setw(13)<<"|"<<endl;
	cout<<"|"<<setfill('_')<<setw(24)<<"|"<<setw(23)<<"|"<<setw(26)<<"|"<<setw(16)<<"|"<<setw(35)<<"|"<<setw(26)<<"|"<<endl;
	cout<<"|"<<setfill(' ')<<setw(17)<<"METER RENT "<<setw(7)<<"|"<<setw(13)<<" "<<setw(10)<<"|"<<setw(16)<<"GST"<<setw(10)<<"|"<<setw(8)<<gst<<setw(8)<<"|"<<setw(26)<<"BILL ADJUSTMENT"<<setw(9)<<"|"<<setw(13)<<" "<<setw(13)<<"|"<<endl;

cout<<"|"<<setfill('_')<<setw(24)<<"|"<<setfill('_')<<setw(23)<<"|"<<setfill('_')<<setw(26)<<"|"<<setfill('_')<<setw(16)<<"|"<<setfill('_')<<setw(35)<<"|"<<setfill('_')<<setw(26)<<"|"<<endl;
	
	cout<<"|"<<setfill(' ')<<setw(22)<<"FUEL PRICE ADJUSTMENT"<<setw(2)<<"|"<<setw(13)<<fuelPriceAdjusment<<setw(10)<<"|"<<setw(16)<<"INCOME TAX"<<setw(10)<<"|"<<setw(8)<<" "<<setw(8)<<"|"<<setw(23)<<"INSTALLMENT"<<setw(12)<<"|"<<setw(13)<<" "<<setw(13)<<"|"<<endl;

			cout<<"|"<<setfill('_')<<setw(24)<<"|"<<setfill('_')<<setw(23)<<"|"<<setfill('_')<<setw(26)<<"|"<<setfill('_')<<setw(16)<<"|"<<setfill('_')<<setw(35)<<"|"<<setfill('_')<<setw(26)<<"|"<<endl;

	cout<<"|"<<setfill(' ')<<setw(17)<<"F.C SURCHARGE"<<setw(7)<<"|"<<setw(13)<<fcSurcharge<<setw(10)<<"|"<<setw(16)<<"EXTRA TAX"<<setw(10)<<"|"<<setw(8)<<" "<<setw(8)<<"|"<<setw(23)<<"SUBSIDIES"<<setw(12)<<"|"<<setw(13)<<" "<<setw(13)<<"|"<<endl;

	cout<<"|"<<setfill('_')<<setw(24)<<"|"<<setw(23)<<"|"<<setw(26)<<"|"<<setw(16)<<"|"<<setw(35)<<"|"<<setw(26)<<"|"<<endl;
	
cout<<"|"<<setfill(' ')<<setw(17)<<"T.R SURCHARGE"<<setw(7)<<"|"<<setw(13)<<" "<<setw(10)<<"|"<<setfill(' ')<<setw(18)<<"N.J SURCHARGE"<<setw(8)<<"|"<<setw(8)<<" "<<setw(8)<<"|"<<setw(23)<<"TOTAL FPA"<<setw(12)<<"|"<<setw(13)<<totalFpa<<setw(13)<<"|"<<endl;	

	cout<<"|"<<setfill('_')<<setw(24)<<"|"<<setw(23)<<"|"<<setw(26)<<"|"<<setw(16)<<"|"<<setw(35)<<"|"<<setw(26)<<"|"<<endl;

	cout<<"|"<<setfill(' ')<<setw(21)<<"QTR TARRIF ADJ/DMC"<<setw(3)<<"|"<<setw(13)<<qtrTarrif<<setw(10)<<"|"<<setw(16)<<"R-STAX"<<setw(10)<<"|"<<setw(8)<<""<<setw(8)<<"|"<<setw(28)<<"PAYABLE WITHIN DUE DATE"<<setw(7)<<"|"<<setw(13)<<payableWithinDate<<setw(13)<<"|"<<endl;	
	
	cout<<"|"<<setfill('_')<<setw(24)<<"|"<<setw(23)<<"|"<<setfill('_')<<setw(26)<<"|"<<setfill('_')<<setw(16)<<"|"<<setfill('_')<<setw(35)<<"|"<<setfill('_')<<setw(26)<<"|"<<endl;
	
	cout<<"|"<<setfill(' ')<<setw(15)<<"TOTAL"<<setw(9)<<"|"<<setw(13)<<total1<<setw(10)<<"|"<<setw(16)<<""<<setw(10)<<"|"<<setw(8)<<""<<setw(8)<<"|"<<setw(23)<<"L.P SURCHARGE"<<setw(12)<<"|"<<setw(13)<<lpSurcharge<<setw(13)<<"|"<<endl;
	
	cout<<"|"<<setfill('_')<<setw(24)<<"|"<<setw(23)<<"|"<<setfill('_')<<setw(26)<<"|"<<setfill('_')<<setw(16)<<"|"<<setfill('_')<<setw(35)<<"|"<<setfill('_')<<setw(26)<<"|"<<endl;
	
	cout<<"|"<<setfill(' ')<<setw(21)<<" "<<setw(3)<<"|"<<setw(13)<<" "<<setw(10)<<"|"<<setw(16)<<" "<<setw(10)<<"|"<<setw(8)<<" "<<setw(8)<<"|"<<setw(23)<<" PAYABLE AFTER DUE DATE"<<setw(12)<<"|"<<setw(13)<<payableAfterDate<<setw(13)<<"|"<<endl;
	
	
	cout<<"|"<<setfill('_')<<setw(24)<<"|"<<setw(23)<<"|"<<setfill('_')<<setw(26)<<"|"<<setfill('_')<<setw(16)<<"|"<<setfill('_')<<setw(35)<<"|"<<setfill('_')<<setw(26)<<"|"<<endl;
	
	cout<<"|"<<setfill(' ')<<setw(33)<<"BILL CALCULATION"<<setw(14)<<"|"<<setw(16)<<"GST ON FPA"<<setw(10)<<"|"<<setw(8)<<gstOnFpa<<setw(8)<<"|"<<setw(61)<<"|"<<endl;
	
	cout<<"|"<<setfill(' ')<<setw(33)<<" "<<setw(14)<<"|"<<setw(16)<<"ED ON FPA"<<setw(10)<<"|"<<setw(8)<<" "<<setw(8)<<"|"<<setw(61)<<"|"<<endl;
	
	cout<<"|"<<setfill(' ')<<setw(33)<<" "<<setw(14)<<"|"<<setw(16)<<"S.TAX ON FPA"<<setw(10)<<"|"<<setw(8)<<" "<<setw(8)<<"|"<<setw(61)<<"|"<<endl;
	
	cout<<"|"<<setfill(' ')<<setw(33)<<" "<<setw(14)<<"|"<<setw(16)<<"IT ON FPA"<<setw(10)<<"|"<<setw(8)<<" "<<setw(8)<<"|"<<setw(61)<<"|"<<endl;
	
	cout<<"|"<<setfill(' ')<<setw(33)<<" "<<setw(14)<<"|"<<setw(16)<<"ET ON FPA"<<setw(10)<<"|"<<setw(8)<<" "<<setw(8)<<"|"<<setw(61)<<"|"<<endl;
	
	cout<<"|"<<setfill('_')<<setw(47)<<"|"<<setfill('_')<<setw(26)<<"|"<<setfill('_')<<setw(16)<<"|"<<setfill('_')<<setw(61)<<"|"<<endl;
	
	cout<<"|"<<setfill(' ')<<setw(33)<<" "<<setw(14)<<"|"<<setw(16)<<"TOTAL TAX ON FPA"<<setw(10)<<"|"<<setw(8)<<gstOnFpa<<setw(8)<<"|"<<setw(61)<<"|"<<endl;
	
	cout<<"|"<<setfill('_')<<setw(47)<<"|"<<setfill('_')<<setw(26)<<"|"<<setfill('_')<<setw(16)<<"|"<<setfill('_')<<setw(61)<<"|"<<endl;
	
	cout<<"|"<<setfill(' ')<<setw(47)<<"|"<<setw(16)<<"TOTAL"<<setw(10)<<"|"<<setw(8)<<total2<<setw(8)<<"|"<<setw(61)<<"|"<<endl;	
	
	cout<<"|"<<setfill('_')<<setw(47)<<"|"<<setfill('_')<<setw(26)<<"|"<<setfill('_')<<setw(16)<<"|"<<setfill('_')<<setw(61)<<"|"<<endl;
}
