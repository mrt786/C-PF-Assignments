/* 	NAME:	Muhammad Rehan Tariq
	ID:	23I-0034
		ASSITGNMENST#2
*/
#include<iostream>
#include<string>
using namespace std;
int main()
{	string condition,installedCondition,optionAdded;
	cout<<"Start General Diagnosis";
	cout<<"\nRecord symptom information -\nDONE";
	cout<<"\nReboot server to see if condition still exists - \n DONE";
	cout<<" Is this a newly installed server";
	cin>>installedCondition;
	if((installedCondition=="Yes") || (installedCondition=="No")) 
	{	
		if(installedCondition=="Yes")
		{	cout<<"Please reseat any components that may have come loose during shipping-\nDONE";
			cout<<"'Reboot the server - DONE";
			cout<<"Does the condition still exist?";
			cin>>condition;
			if(condition=="Yes"||condition=="No")
				{	if(condition=="No")
					{	cout<<"\nRecording all actions taken dor future -DONE";
						cout<<"\nCongratulations, your server problems are solved.";
						return 0;
					}
					else
					{	cout<<"Were options added or was the configuration changed recently?";
						cin>>optionAdded;
						if(optionAdded=="Yes"||optionAdded=="No")
						{	if(optionAdded=="No")
							{	cout<<"Check for Service notification -DONE";
								cout<<"\nDownload the lastest software and firmware from the website";
								cout<<"\nDoes the condition still exist?";
								cin>>condition;
								if(condition=="Yes"||condition=="No")
									{	if(condition=="No")
										{	cout<<"\nRecording all actions taken dor future -DONE";
											cout<<"\nCongratulations, your server problems are solved.";
											return 0;
										}
										else
										{	cout<<"\nIsolate and minimize the memoryconfiguration -DONE";
											cout<<"\nDoes condition still exists";
											cin>>condition;
											if(condition=="Yes"||condition=="No")
											{	if(condition=="No")
												{	cout<<"\nRecording all actions taken dor future -DONE";
													cout<<"\nCongratulations, your server problems are solved.";
													return 0;
												}
												else
												{	cout<<"\nBreak Server down to minimal configuration -DONE";
													cout<<"\nDoes condition stil exist?";
													cin>>condition;
													if(condition=="Yes"||condition=="No")
													{	if(condition=="No")
														{
															cout<<"\nAdd one part at a time back to configuration to isolate faulty component -DONE";
															cout<<"\n Does condtion still exist";
															cin>>condition;
															if(condition=="Yes"||condition=="No")
															{	if(condition=="No")
																{	cout<<"\nRecording all actions taken dor future -DONE";
																	cout<<"\nCongratulations, your server problems are solved.";
																	return 0;
																}
																else
																{	cout<<"\nEnsure the following information is avialable:\n Survey configuration snapshots\nOS event log file\nfull crash dump -DONE";
																cout<<"\nCall HP Service Provider -DONE";
																return 0;
																
																}
															}
															else
															{	cout<<"\nEnter Yes or No";
																return 0;
															}
														}	
														else
															{
															}
													}
													else
													{	cout<<"\nEnter Yes or No";
														return 0;
													}	
												}
											}
											else
											{	cout<<"\nEnter Yes or No";
												return 0;
											}
										}
									}
								else
								{	cout<<"\nEnter Yes or No";
									return 0;
								}
							}
							else
							{	cout<<"\nIsolate what has changed.Verify it was installed correctly.Restore server to last known working state or original shipped configuration -DONE";
								cout<<"\nDoes condition stil exists";
								cin>>condition;
								if(condition=="Yes"||condition=="No")
								{	if(condition=="No")
									{		cout<<"\nRecording all actions taken dor future -DONE";
											cout<<"\nCongratulations, your server problems are solved.";
											return 0;
										}
										else
										{	cout<<"\nIsolate and minimize the memoryconfiguration -DONE";
											cout<<"\nDoes condition still exists";
											cin>>condition;
											if(condition=="Yes"||condition=="No")
											{	if(condition=="No")
												{	cout<<"\nRecording all actions taken dor future -DONE";
													cout<<"\nCongratulations, your server problems are solved.";
													return 0;
												}
												else
												{	cout<<"\nBreak Server down to minimal configuration -DONE";
												cout<<"\nDoes condition stil exist?";
												cin>>condition;
												if(condition=="Yes"||condition=="No")
												{	if(condition=="No")
													{
														cout<<"\nAdd one part at a time back to configuration to isolate faulty component -DONE";
														cout<<"\n Does condtion still exist";
														cin>>condition;
														if(condition=="Yes"||condition=="No")
														{	if(condition=="No")
															{	cout<<"\nRecording all actions taken dor future -DONE";
																cout<<"\nCongratulations, your server problems are solved.";
																return 0;
															}
															else
															{	cout<<"\nEnsure the following information is avialable:\n Survey configuration snapshots\nOS event log file\nfull crash dump -DONE";
																cout<<"\nCall HP Service Provider -DONE";
																return 0;
															}
														}
														else
														{	cout<<"\nEnter Yes or No";
															return 0;
														}
													}
													else
													{	cout<<"\nTroubleshoot or replace basic server spare part -DONE";
														cout<<"\nDoes condition still exist?";
														cin>>condition;
														if(condition=="Yes"||condition=="No")
														{	if(condition=="No")
															{	cout<<"Record symptom and error information on repair taq if sending back a failed part";
																return 0;
															}
															else
															{	cout<<"\nEnsure the following information is avialable:\n Survey configuration snapshots\nOS event log file\nfull crash dump -DONE";
																cout<<"\nCall HP Service Provider -DONE";
																return 0;
															}
														}
														else
														{	cout<<"\nEnter Yes or No";
															return 0;
														}
													}
												}
												else
												{	cout<<"\nEnter Yes or No";
													return 0;
												}	
												}
											}
										else
										{	cout<<"\nEnter Yes or No";
											return 0;
										}
						
									}						
								}	
								else
								{	cout<<"Enter Yes or No";
									return 0;
								}
							}
						}
						else
						{
							cout<<"Enter Yes or No";
							return 0;
						}
					}
				}
			else
			{
				cout<<"Enter Yes or No";
				return 0;
			}
		}		
		else
		{	cout<<"<Were options added or was the configuratiom changed recently?";
			cin>>optionAdded;
			if(optionAdded=="Yes"||optionAdded=="No")
			{	if(optionAdded=="No")
				{	cout<<"Check for Service notification -DONE";
					cout<<"\nDownload the lastest software and firmware from the website -DONE";
					cout<<"\nDoes the condition still exist?";
					cin>>condition;
					if(condition=="Yes"||condition=="No")
						{	if(condition=="No")
							{	cout<<"\nRecording all actions taken dor future -DONE";
								cout<<"\nCongratulations, your server problems are solved.";
								return 0;
							}
							else
							{	cout<<"\nIsolate and minimize the memoryconfiguration -DONE";
								cout<<"\nDoes condition still exists";
								cin>>condition;
								if(condition=="Yes"||condition=="No")
								{	if(condition=="No")
									{	cout<<"\nRecording all actions taken dor future -DONE";
										cout<<"\nCongratulations, your server problems are solved.";
										return 0;
									}
									else
									{	cout<<"\nBreak Server down to minimal configuration -DONE";
									cout<<"\nDoes condition stil exist?";
									cin>>condition;
									if(condition=="Yes"||condition=="No")
									{	if(condition=="No")
										{
											cout<<"\nAdd one part at a time back to configuration to isolate faulty component -DONE";
											cout<<"\n Does condtion still exist";
											cin>>condition;
											if(condition=="Yes"||condition=="No")
											{	if(condition=="No")
												{	cout<<"\nRecording all actions taken dor future -DONE";
													cout<<"\nCongratulations, your server problems are solved.";
													return 0;
												}
												else
												{	cout<<"\nEnsure the following information is avialable:\n Survey configuration snapshots\nOS event log file\nfull crash dump -DONE";
													cout<<"\nCall HP Service Provider -DONE";
													return 0;
												}
											}
											else
											{	cout<<"\nEnter Yes or No";
												return 0;
											}
										}
										else
										{	cout<<"\nTroubleshoot or replace basic server spare part -DONE";
											cout<<"\nDoes condition still exist?";
											cin>>condition;
											if(condition=="Yes"||condition=="No")
											{	if(condition=="No")
												{	cout<<"Record symptom and error information on repair taq if sending back a failed part";
													return 0;
												}
												else
												{	cout<<"\nEnsure the following information is avialable:\n Survey configuration snapshots\nOS event log file\nfull crash dump -DONE";
													cout<<"\nCall HP Service Provider -DONE";
													return 0;
												}
											}
											else
											{	cout<<"\nEnter Yes or No";
												return 0;
											}
										}
									}
									else
									{	cout<<"\nEnter Yes or No";
										return 0;
									}	
									}
								}
								else
								{	cout<<"\nEnter Yes or No";
									return 0;
								}
							}
						}
					else
					{	cout<<"\nEnter Yes or No";
						return 0;
					}
				}
				else
							{	cout<<"\nIsolate what has changed.Verify it was installed correctly.Restore server to last known working state or original shipped configuration -DONE";
								cout<<"\nDoes condition stil exists";
								cin>>condition;
								if(condition=="Yes"||condition=="No")
								{	if(condition=="No")
									{		cout<<"\nRecording all actions taken dor future -DONE";
											cout<<"\nCongratulations, your server problems are solved.";
											return 0;
										}
										else
										{	cout<<"\nIsolate and minimize the memoryconfiguration -DONE";
											cout<<"\nDoes condition still exists";
											cin>>condition;
											if(condition=="Yes"||condition=="No")
											{	if(condition=="No")
												{	cout<<"\nRecording all actions taken dor future -DONE";
													cout<<"\nCongratulations, your server problems are solved.";
													return 0;
												}
												else
												{	cout<<"\nBreak Server down to minimal configuration -DONE";
												cout<<"\nDoes condition stil exist?";
												cin>>condition;
												if(condition=="Yes"||condition=="No")
												{	if(condition=="No")
													{
														cout<<"\nAdd one part at a time back to configuration to isolate faulty component -DONE";
														cout<<"\n Does condtion still exist";
														cin>>condition;
														if(condition=="Yes"||condition=="No")
														{	if(condition=="No")
															{	cout<<"\nRecording all actions taken dor future -DONE";
																cout<<"\nCongratulations, your server problems are solved.";
																return 0;
															}
															else
															{	cout<<"\nEnsure the following information is avialable:\n Survey configuration snapshots\nOS event log file\nfull crash dump -DONE";
																cout<<"\nCall HP Service Provider -DONE";
																return 0;
															}
														}
														else
														{	cout<<"\nEnter Yes or No";
															return 0;
														}
													}
													else
													{	cout<<"\nTroubleshoot or replace basic server spare part -DONE";
														cout<<"\nDoes condition still exist?";
														cin>>condition;
														if(condition=="Yes"||condition=="No")
														{	if(condition=="No")
															{	cout<<"Record symptom and error information on repair taq if sending back a failed part";
																return 0;
															}
															else
															{	cout<<"\nEnsure the following information is avialable:\n Survey configuration snapshots\nOS event log file\nfull crash dump -DONE";
																cout<<"\nCall HP Service Provider -DONE";
																return 0;
															}
														}
														else
														{	cout<<"\nEnter Yes or No";
															return 0;
														}
													}
												}
												else
												{	cout<<"\nEnter Yes or No";
													return 0;
												}	
												}
											}
										else
										{	cout<<"\nEnter Yes or No";
											return 0;
										}
						
									}						
								}	
								else
								{	cout<<"Enter Yes or No";
									return 0;
								}
							}		
			}
			else
			{
				cout<<"Enter Yes or No";
				return 0;
			}
		}			
	}
	else
	{
		cout<<"Enter Yes or No";
		return 0;
	}
}


