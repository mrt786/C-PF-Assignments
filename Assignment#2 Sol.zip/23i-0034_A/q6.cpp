/* 	NAME:	Muhammad Rehan Tariq
	ID:	23I-0034
		ASSITGNMENST#2*/
#include<iostream>
using namespace std;
int main()
{	int noOfDays,hours=8;
	float tax,expectedSalary;
	cout<<"\n Enter number of days";
	if(cin>>noOfDays)
	{
		if((noOfDays>0)&&(noOfDays<=30))
		{	if(noOfDays>=25 && noOfDays<=30)
			{	
				expectedSalary=900*(noOfDays*hours);
				tax=(expectedSalary*5)/100;
				expectedSalary=expectedSalary-tax;
				cout<<"\nThe expected Salary of the emloyee is RS:"<<expectedSalary;
			}
			else if((noOfDays>=15)&&(noOfDays>=24))
			{
				expectedSalary=850*(noOfDays*hours);
				tax=(expectedSalary*7)/100;
				expectedSalary=expectedSalary-tax;
				cout<<"\nThe expected Salary of the emloyee is RS:"<<expectedSalary;
			}
			else
			{
				expectedSalary=600*(noOfDays*hours);
				tax=(expectedSalary*10)/100;
				expectedSalary=expectedSalary-tax;
				cout<<"\nThe expected Salary of the emloyee is RS:"<<expectedSalary;
			}
		}
		else 
			cout<<"Invalid Input";
	}
	else
		cout<<"Invalid Days";
}
