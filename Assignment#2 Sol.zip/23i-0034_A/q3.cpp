/*	NAME:	Muhammad Rehan Tariq
	ID:	23I-0034
	ASSITGNMENST#2
*/
#include<iostream>
using namespace std;
int main()
{
	short result,value,b;
	cout<<"Enter the value:";
	if(cin>>value)
	{	result=(value<<6);
		result=result-value;
		cout<<result;
	}
	else
		cout<<"Invalid Input";	
}
