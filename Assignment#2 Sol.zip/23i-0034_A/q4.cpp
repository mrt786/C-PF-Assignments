/* 	NAME:	Muhammad Rehan Tariq
	ID:	23I-0034
		ASSITGNMENST#2
*/
#include<iostream>
using namespace std;
int main()
{	unsigned short int number,second=0,minute=0,hour=0;
	if(cin>>number)//Input validation
	{	second=number&63;
		minute=number>>6;
		minute=minute&63;
		hour=number>>12;
		hour=hour&15;
		cout<<hour<<"hrs"<<minute<<"mins"<<second<<"sec";	
	}
	else
		cout<<"Invalid Input";
}
