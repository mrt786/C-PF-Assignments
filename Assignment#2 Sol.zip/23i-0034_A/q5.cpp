/*	NAME:	Muhammad Rehan Tariq
	ID:	23I-0034
	ASSITGNMENST#2
*/
#include<iostream>
using namespace std;
int main()
{
	int totalAmount,withdrawLimit=50000,currencyNOte5000=0,currencyNOte1000=0,currencyNOte500=0;
	cout<<"ENTER THE AMOUNT YOU WANT TO WITHDRAW IN THE RANGE OF 500-50000:";
	cin>>totalAmount;
		if(totalAmount%500==0 && totalAmount<=withdrawLimit)//checking that the input enetered by user is in the range or not and divisible by 500 or not
		{	if(totalAmount>=5000)
			{	currencyNOte5000=totalAmount/5000;
				totalAmount=totalAmount%5000;
			}
			if(totalAmount>=1000)
			{	currencyNOte1000=totalAmount/1000;
				totalAmount=totalAmount%1000;
			}
			if(totalAmount>=500)
			{	currencyNOte500=totalAmount/500;
			}
			cout<<currencyNOte5000<<"Rs 5000 note,"<<currencyNOte1000<<"Rs 1000 note,"<<currencyNOte500<<"Rs 500 note";
		}
		else
			cout<<"\nNot in the range (500-50000) or not divisble by 500";
}
