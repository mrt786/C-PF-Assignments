/* 	NAME:	Muhammad Rehan Tariq
	ID:	23I-0034
		ASSITGNMENST#2
*/
#include<iostream>
using namespace std;
#include<cstdlib>
#include<ctime>
int main()
{	unsigned seed=time(0);
	srand(seed);
	int maximumValue,num1,num2,minValue;
	float result,userResult;
	char operation,character;//charcter is either X or Y
	cout<<"Enter Anyone operation from [+,-,*/]"<<endl;
	cin>>operation;
	cout<<"Are negative values allowed in the exerxise [Y or N]"<<endl;
	cin>>character;
	cout<<"What is the maximum value of this exercise:"<<endl;
	cin>>maximumValue;
	if(maximumValue>0)
	{	if((character=='Y') || (character=='N'))
		{	if(character=='Y')
			{	minValue=-maximumValue;
				num1=(rand()%(maximumValue-minValue+1)+minValue);
				num2=(rand()%(maximumValue-minValue+1)+minValue);
			}
			else
			{	minValue=0;
				num1=(rand()%(maximumValue+minValue+1)+minValue);
				num2=(rand()%(maximumValue+minValue+1)+minValue);
			}	
		}
		else
		{	cout<<"Invalid Character";
			return 0;
		}
	}
	else
	{	cout<<"maximum value must be greater than 0"; 
		return 0;
	}
	switch(operation)
	{	case '+':
			result=num1+num2;
			cout<<num1<<"+"<<num2<<"=";
			cin>>userResult;
			if(userResult==result)
				cout<<"You won";
			else
				cout<<"You lose";
			break;
		case '-':
			if(num2>num1)
				num2=rand()%num1;
			result=num1-num2;
			cout<<"("<<num1<<")-("<<num2<<")=";
			cin>>userResult;
			if(userResult==result)
				cout<<"You won";
			else
				cout<<"You lose";
		break;
		case '*':
			result=num1*num2;
			cout<<num1<<"*"<<num2<<"=";
			cin>>userResult;
			if(userResult==result)
				cout<<"You won";
		else
			cout<<"\nYou lose";
		break;
		case '/':
			if(num2==0)
				num2=num2+1;
			result=num1+num2;
			cout<<num1<<"/"<<num2<<"=";
			cin>>userResult;
			if(userResult==result)
				cout<<"You won";
			else
				cout<<"You lose";
		break;
		default:
			cout<<"\nInvalid Operation";
			break;
	}
}
