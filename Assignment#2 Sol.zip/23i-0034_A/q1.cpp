/* 	NAME:	Muhammad Rehan Tariq
	ID:	23I-0034
		ASSITGNMENST#2*/
#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	int totalEggs,noOfEggsPacking,leftOverEggs;
	cout<<"Enter total number of eggs:";
	cin>>totalEggs;
		if(totalEggs>0)//totalEggs cannot be zero and -ve
		{	//for 30 eggs packing
			noOfEggsPacking=totalEggs/30;
			leftOverEggs=totalEggs%30;
			cout<<"\nNumber of 30 eggs packing:"<<noOfEggsPacking<<"\tNumber of leftover eggs:"<<leftOverEggs;
			//for 24 eggs packing
			noOfEggsPacking=totalEggs/24;
			leftOverEggs=totalEggs%24;
			cout<<"\nNumber of 24 eggs packing:"<<noOfEggsPacking<<"\tNumber of leftover eggs:"<<leftOverEggs;
			//for 18 eggs packing
			noOfEggsPacking=totalEggs/18;
			leftOverEggs=totalEggs%18;
			cout<<"\nNumber of 18 eggs packing:"<<noOfEggsPacking<<"\tNumber of leftover eggs:"<<leftOverEggs;			
			//for 12 eggs packing
			noOfEggsPacking=totalEggs/12;
			leftOverEggs=totalEggs%12;
			cout<<"\nNumber of 12 eggs packing:"<<noOfEggsPacking<<"\tNumber of leftover eggs:"<<leftOverEggs;
			//for 6 egggs packing
			noOfEggsPacking=totalEggs/6;
			leftOverEggs=totalEggs%6;
			cout<<"\nNumber of 06 eggs packing:"<<noOfEggsPacking<<"\tNumber of leftover eggs:"<<leftOverEggs;
		}
		else
			cout<<"\nTotal Eggs must be greater than zero";
}
