/* 	NAME:	Muhammad Rehan Tariq
	ID:	23I-0034
		ASSITGNMENST#2*/
#include<iostream>
using namespace std;
int main()
{	int day,month,year;
	cout<<"Enter date in the range of (1-31), month (1-12) and a four digit year:";
	cin>>day>>month>>year;
	if(day>=1 && day<=31) 	//Checking the date is in the range or not
	{	if(month>=1 && month<=12) //Checking the month is in the range or not
		{	if(year/1000>=1 && year/1000<=9) //checking the year is four digit or not
			{	cout<<"your inputs are valid"<<endl;
				year=year%100;
				(day*month==year)?cout<<"Date is Magic":cout<<"Date is not Magic";
			}
			else
				cout<<"\n year is not  four digit"; 
		}
				
		else
			cout<<"\nMonth is not in the range";	
	}
	else
			cout<<"\nDay is not in the range";
}

